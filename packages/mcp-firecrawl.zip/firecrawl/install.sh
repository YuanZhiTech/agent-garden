#!/bin/bash
set -e
MCP_NAME="firecrawl"
MCP_DIR="$HOME/.agent-garden/mcp"
echo ""; echo "  🌸 安装 MCP: Firecrawl"; echo ""
mkdir -p "$MCP_DIR"
SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
SETTINGS_FILE="$HOME/.claude/settings.json"
if [ ! -f "$SETTINGS_FILE" ]; then
  mkdir -p "$HOME/.claude"
  echo '{"mcpServers":{}}' > "$SETTINGS_FILE"
fi
node -e "
const fs = require('fs');
const settings = JSON.parse(fs.readFileSync('$SETTINGS_FILE', 'utf-8'));
const mcp = JSON.parse(fs.readFileSync('$SCRIPT_DIR/mcp.json', 'utf-8'));
if (!settings.mcpServers) settings.mcpServers = {};
Object.assign(settings.mcpServers, mcp.mcpServers);
fs.writeFileSync('$SETTINGS_FILE', JSON.stringify(settings, null, 2));
console.log('  ✓ 配置已写入 settings.json');
"
echo ""; echo "  ✓ Firecrawl 安装完成！"; echo "  重启 Claude Code 即可使用"; echo ""