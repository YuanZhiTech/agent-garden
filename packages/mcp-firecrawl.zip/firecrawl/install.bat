@echo off
chcp 65001 >nul 2>&1
setlocal enabledelayedexpansion
echo.
echo   🌸 安装 MCP: Firecrawl
echo.
set "MCP_NAME=firecrawl"
set "MCP_DIR=%USERPROFILE%\.agent-garden\mcp"
if not exist "%MCP_DIR%" mkdir "%MCP_DIR%"
copy "%~dp0mcp.json" "%MCP_DIR%\%MCP_NAME%.json" >nul
set "SETTINGS_FILE=%USERPROFILE%\.claude\settings.json"
if not exist "%SETTINGS_FILE%" (
    if not exist "%USERPROFILE%\.claude" mkdir "%USERPROFILE%\.claude"
    echo {"mcpServers":{}} > "%SETTINGS_FILE%"
)
powershell -Command ^
    "$s = Get-Content '%SETTINGS_FILE%' -Raw | ConvertFrom-Json;" ^
    "$m = Get-Content '%~dp0mcp.json' -Raw | ConvertFrom-Json;" ^
    "if (-not $s.mcpServers) { $s | Add-Member -Name 'mcpServers' -Value @{} -MemberType NoteProperty };" ^
    "$m.mcpServers.PSObject.Properties | %%{ $s.mcpServers | Add-Member -Name $_.Name -Value $_.Value -MemberType NoteProperty -Force };" ^
    "$s | ConvertTo-Json -Depth 10 | Set-Content '%SETTINGS_FILE%' -Encoding utf8"
if !errorlevel! equ 0 ( echo   ✓ 配置已写入 ) else ( echo   ⚠ 配置写入失败 )
echo.
echo   ✓ Firecrawl 安装完成！
echo   重启 Claude Code 即可使用
echo.
pause