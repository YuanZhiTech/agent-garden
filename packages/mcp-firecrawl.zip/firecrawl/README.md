# Firecrawl MCP — Agent花园精选

## 功能
网页抓取 — 深度爬取、内容提取、网站分析

## 安装
1. 下载本文件夹（zip）
2. 解压
3. 运行安装脚本：
   - **Mac**: 终端执行 `bash install.sh`
   - **Windows**: 双击 `install.bat`
4. 重启 Claude Code

## 环境变量
FIRECRAWL_API_KEY — Firecrawl API密钥（可选，不填用免费额度）

## 验证
安装后启动 Claude Code，问它"你能用 Firecrawl 做什么？"

---
*Agent花园精选 MCP · agent-garden.com*