# GitHub MCP — Agent花园精选

## 功能
代码仓库管理 — 读仓库、建PR、处理Issue

## 安装
1. 下载本文件夹（zip）
2. 解压
3. 运行安装脚本：
   - **Mac**: 终端执行 `bash install.sh`
   - **Windows**: 双击 `install.bat`
4. 重启 Claude Code

## 环境变量
GITHUB_TOKEN — GitHub Personal Access Token

## 验证
安装后启动 Claude Code，问它"你能用 GitHub 做什么？"

---
*Agent花园精选 MCP · agent-garden.com*