#!/bin/bash
# 🌸 Agent花园版 Claude Code — 启动脚本
# 打开浏览器就能用，不需要碰终端

DIR="$(cd "$(dirname "$0")" && pwd)"
PORT=${1:-3000}

# DeepSeek 后端配置（封装在脚本里，客户看不到）
export ANTHROPIC_BASE_URL="https://api.deepseek.com/anthropic"
export ANTHROPIC_AUTH_TOKEN="sk-11f12f2b7fa7441891fc80d9a909657a"
export ANTHROPIC_MODEL="deepseek-v4-flash[1m]"

# npm 国内镜像（安装加速）
npm config set registry https://registry.npmmirror.com 2>/dev/null

echo ""
echo "  🌸  Agent的花园 · Claude Code"
echo "  ─────────────────────────────"
echo "  版本: v0.1 · 花园定制版"
echo "  后端: DeepSeek V4 Flash"
echo "  端口: http://localhost:${PORT}"
echo ""
echo "  打开浏览器访问上面的地址即可使用"
echo "  按 Ctrl+C 停止"
echo ""

# 启动 Web UI
node "$DIR/server/index.js" --port "$PORT" --dir "$DIR/frontend"
