import { chromium } from 'playwright';

const PORT = 3459;
const DEMO_DIR = '/Users/zbbsjl_72/Desktop/demo';

// Create demo folder
import { mkdirSync } from 'fs';
mkdirSync(DEMO_DIR, { recursive: true });

const browser = await chromium.launch({ headless: false, args: ['--window-size=1400,900'] });
const page = await browser.newPage({ viewport: { width: 1400, height: 900 } });

console.log('🚀 Demo starting...');
await page.goto(`http://localhost:${PORT}`, { waitUntil: 'networkidle' });
await page.waitForTimeout(2000);

// ── Step 1: Select folder ─────────────────────────
console.log('📁 Step 1: Selecting demo folder...');
const pickerBtn = page.locator('#btn-pick-dir');
await pickerBtn.waitFor({ state: 'visible', timeout: 10000 });
await pickerBtn.click();
await page.waitForTimeout(1000);

// On Mac, the native dialog opens. Playwright needs special handling.
// Try to type the directory path if there's a text input
const dirInput = page.locator('input[type="text"]').first();
if (await dirInput.isVisible().catch(() => false)) {
  await dirInput.fill(DEMO_DIR);
  await page.keyboard.press('Enter');
}
await page.waitForTimeout(3000);

// ── Step 2: Show interface ─────────────────────────
console.log('🖥️ Step 2: Interface ready (pause 5s for recording)');
await page.waitForTimeout(5000);

// ── Step 3: Skills panel ───────────────────────────
console.log('🎯 Step 3: Opening Skills panel...');
const skillsBtn = page.locator('#btn-skills');
if (await skillsBtn.isVisible().catch(() => false)) {
  await skillsBtn.click();
  await page.waitForTimeout(3000);
  // Close skills
  await skillsBtn.click();
  await page.waitForTimeout(1000);
}

// ── Step 4: MCP panel ──────────────────────────────
console.log('🔌 Step 4: Opening MCP panel...');
const mcpBtn = page.locator('#btn-mcp');
if (await mcpBtn.isVisible().catch(() => false)) {
  await mcpBtn.click();
  await page.waitForTimeout(3000);
  await mcpBtn.click();
  await page.waitForTimeout(1000);
}

// ── Step 5: Type a prompt ─────────────────────────
console.log('💬 Step 5: Sending prompt...');
const input = page.locator('#user-input');
await input.waitFor({ state: 'visible', timeout: 10000 });
await input.fill('帮我写一个番茄钟网页，HTML+CSS+JS，保存到这个文件夹');
await page.waitForTimeout(2000);

const sendBtn = page.locator('#btn-send');
await sendBtn.click();

// ── Step 6: Wait for response ──────────────────────
console.log('⏳ Step 6: Waiting for Claude to respond...');
// Watch for new messages appearing
try {
  await page.waitForSelector('.message, .assistant-message', { timeout: 120000 });
  console.log('✅ Claude is responding!');
} catch {
  console.log('⚠️ Waiting for any response...');
}

// Wait a bit to show the response streaming in
await page.waitForTimeout(15000);

console.log('✅ Demo complete!');
console.log('');
console.log('--- NARRATION SCRIPT ---');
console.log('[00:00] 这是 Agent花园·Code——基于 Claude Code 引擎，打开浏览器就能用的 AI 工作站');
console.log('[00:10] 左边是会话列表，下面是输入框，右上角是功能按钮');
console.log('[00:20] Skills 面板：里面是我们积累的实用技能，一键调用');
console.log('[00:35] MCP 面板：连接各种工具，让 AI 能操作真实世界');
console.log('[00:50] 输入需求，Claude Code 直接生成代码并保存到本地');
console.log('[01:30] 它不只是聊天，是真的能帮你干活');
console.log('[01:40] agent-garden.com · 199 元起，打开浏览器就能用的 AI 工作站');
