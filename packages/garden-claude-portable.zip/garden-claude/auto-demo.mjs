import { chromium } from 'playwright';
import { mkdirSync, writeFileSync } from 'fs';

const PORT = 3458;
const DEMO_DIR = '/Users/zbbsjl_72/Desktop/demo';

// Prepare demo folder
mkdirSync(DEMO_DIR, { recursive: true });
writeFileSync(`${DEMO_DIR}/readme.md`, '# Demo - Agent Garden Code\n\nThis is a demo workspace.');

const browser = await chromium.launch({ headless: false, args: ['--window-size=1400,920'] });
const page = await browser.newPage({ viewport: { width: 1400, height: 920 } });

console.log('=== Starting automated demo ===\n');

// ── Open Web UI ─────────────────────────────
await page.goto(`http://localhost:${PORT}`, { waitUntil: 'networkidle' });
await page.waitForTimeout(3000);

// ── Set directory via JavaScript ─────────────
console.log('1. Setting demo directory...');
await page.evaluate(async (dir) => {
  // Wait for WebSocket to be ready
  while (!window.__ws || window.__ws.readyState !== WebSocket.OPEN) {
    await new Promise(r => setTimeout(r, 200));
  }
  // Call the directory handler directly
  if (window.__handleDirectoryPicked) {
    await window.__handleDirectoryPicked(dir);
    return 'OK';
  }
  return 'FAILED: handleDirectoryPicked not found';
}, DEMO_DIR);
await page.waitForTimeout(5000);

// ── Show interface ───────────────────────────
console.log('2. Interface ready - pause for recording');
await page.waitForTimeout(5000);

// ── Skills panel ─────────────────────────────
console.log('3. Opening Skills panel...');
await page.click('#btn-skills');
await page.waitForTimeout(4000);
await page.click('#btn-skills');
await page.waitForTimeout(2000);

// ── MCP panel ────────────────────────────────
console.log('4. Opening MCP panel...');
await page.click('#btn-mcp');
await page.waitForTimeout(4000);
await page.click('#btn-mcp');
await page.waitForTimeout(2000);

// ── Type prompt ─────────────────────────────
console.log('5. Sending prompt to Claude Code...');
await page.fill('#user-input', '帮我写一个番茄钟网页，HTML+CSS+JS完整代码，保存到这个文件夹');
await page.waitForTimeout(2000);
await page.click('#btn-send');

// ── Wait for response ────────────────────────
console.log('6. Waiting for Claude Code response...');
let responded = false;
try {
  await page.waitForSelector('.message, [class*="message"], .assistant', { timeout: 15000 });
  responded = true;
} catch {}
await page.waitForTimeout(20000);
console.log('7. Demo running - Claude is responding...');
await page.waitForTimeout(15000);

console.log('\n=== Demo complete! ===');
console.log('Stop recording now.');
