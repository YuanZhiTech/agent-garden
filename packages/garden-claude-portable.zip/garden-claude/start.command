#!/bin/bash
# 🌸 Agent花园版 Claude Code — 双击启动（Mac）
# 双击这个文件，浏览器自动打开

DIR="$(cd "$(dirname "$0")" && pwd)"
cd "$DIR"
node garden-claude.js
