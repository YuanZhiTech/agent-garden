// ── DOM refs ─────────────────────────────────────────────────────────────
const $ = (s) => document.querySelector(s);
const $$ = (s) => document.querySelectorAll(s);

const dom = {
  btnNew: $('#btn-new-session'),
  btnRefresh: $('#btn-refresh'),
  btnPickDir: $('#btn-pick-dir'),
  cwdName: $('#cwd-name'),
  cwdFull: $('#cwd-full .path-bubble'),
  sessionList: $('#session-list'),
  sessionEmpty: $('#session-list-empty'),
  connStatus: $('#connection-status'),
  emptyState: $('#empty-state'),
  messages: $('#messages'),
  permissionDialog: $('#permission-dialog'),
  permTitle: $('#perm-title'),
  permBody: $('#perm-body'),
  permIcon: $('#perm-icon'),
  permOptions: $('#perm-options'),
  permToolLabel: $('#perm-tool-label'),
  inputArea: $('#input-area'),
  userInput: $('#user-input'),
  btnSend: $('#btn-send'),
  btnInterrupt: $('#btn-interrupt'),
  sidebarSessionId: $('#sidebar-session-id'),
  btnCmds: $('#btn-cmds'),
  cmdsDropdown: $('#cmds-dropdown'),
  cmdsList: $('#cmds-list'),
  cmdsEmpty: $('#cmds-empty'),
  btnSkills: $('#btn-skills'),
  skillsDropdown: $('#skills-dropdown'),
  skillsList: $('#skills-list'),
  skillsEmpty: $('#skills-empty'),
  skillChips: $('#skill-chips'),
  btnMcp: $('#btn-mcp'),
  mcpDropdown: $('#mcp-dropdown'),
  mcpList: $('#mcp-list'),
  mcpEmpty: $('#mcp-empty'),
  btnModel: $('#btn-model'),
  modelDropdown: $('#model-dropdown'),
  modelList: $('#model-list'),
  modelEmpty: $('#model-empty'),
  modelLabel: $('#model-label'),
};

// ── State ────────────────────────────────────────────────────────────────
let ws = null;
let reconnectTimer = null;
let reconnectDelay = 1000;
const MAX_RECONNECT_DELAY = 30000;

let state = {
  cwd: null,
  sessionId: null,
  isThinking: false,
  sessions: [], // flat array of { sessionId, summary, customTitle, cwd, lastModified }
  sessionGroups: [], // grouped by directory
  collapsedGroups: {}, // directory → bool for collapse state
  lastEchoedContent: null, // dedup SDK-replayed user messages
  skills: [],         // SlashCommand[] from SDK
  activeSkills: [],   // selected skill names (shown as chips)
  skillsLoaded: false, // whether skills have been fetched at least once
  cmds: [],           // built-in command names from SDK
  cmdsLoaded: false,
  mcpServers: [],     // McpServerStatus[] from SDK
  mcpLoaded: false,   // whether MCP status has been fetched at least once
  models: [],         // ModelInfo[] from SDK
  currentModel: null,
  modelsLoaded: false,
};

// ── WebSocket ────────────────────────────────────────────────────────────

function connect() {
  if (ws && (ws.readyState === WebSocket.OPEN || ws.readyState === WebSocket.CONNECTING)) return;

  const protocol = location.protocol === 'https:' ? 'wss:' : 'ws:';
  const url = `${protocol}//${location.host}`;

  setConnectionStatus('connecting', '连接中...');
  ws = new WebSocket(url);

  ws.onopen = () => {
    setConnectionStatus('connected', '已连接');
    reconnectDelay = 1000;
    // Request session list on connect
    send({ type: 'get_sessions' });
  };

  ws.onmessage = (event) => {
    let data;
    try { data = JSON.parse(event.data); } catch { return; }
    handleServerMessage(data);
  };

  ws.onclose = () => {
    setConnectionStatus('connecting', '重新连接中...');
    scheduleReconnect();
  };

  ws.onerror = () => {
    // onclose will fire after this
  };
}

function scheduleReconnect() {
  if (reconnectTimer) return;
  reconnectTimer = setTimeout(() => {
    reconnectTimer = null;
    reconnectDelay = Math.min(reconnectDelay * 2, MAX_RECONNECT_DELAY);
    connect();
  }, reconnectDelay);
}

function send(data) {
  if (ws && ws.readyState === WebSocket.OPEN) {
    ws.send(JSON.stringify(data));
  }
}

function setConnectionStatus(status, text) {
  // Update only the first text node, preserve the session-id span
  const textNode = dom.connStatus.childNodes[0];
  if (textNode && textNode.nodeType === Node.TEXT_NODE) {
    textNode.textContent = text;
  } else {
    dom.connStatus.prepend(text);
  }
  dom.connStatus.className = `status-${status}`;
}

// ── Server message dispatcher ────────────────────────────────────────────

function handleServerMessage(data) {
  switch (data.type) {
    case 'session_list':
      renderSessionList(data.groups);
      break;

    case 'status':
      handleStatus(data);
      break;

    case 'user_echo':
      cleanupStreamingElements();
      state.lastEchoedContent = data.content;
      appendMessage('user', data.content);
      break;

    case 'user':
      // SDK-replayed user messages from resumed session (dedup against echo)
      if (data.content && data.content !== state.lastEchoedContent) {
        appendMessage('user', data.content);
      }
      break;

    case 'assistant':
      appendAssistantMessage(data);
      break;

    case 'stream_event':
      handleStreamEvent(data);
      break;

    case 'tool_progress':
      handleToolProgress(data);
      break;

    case 'result':
      handleResult(data);
      break;

    case 'permission_request':
      showPermissionRequest(data);
      break;

    case 'permission_timeout':
      hidePermissionDialog();
      appendSystemMsg('权限请求超时，已自动拒绝');
      break;

    case 'permission_denied':
      appendSystemMsg(`工具 "${data.tool_name}" 被拒绝: ${data.message || ''}`);
      break;

    case 'session_info': {
      const isNew = !state.sessionId;
      state.sessionId = data.sessionId;
      state.cwd = data.cwd || state.cwd;
      if (data.model) state.currentModel = data.model;
      updateModelLabel();
      if (isNew) {
        updateUIState();
        setTimeout(refreshSessions, 300);
      }
      break;
    }

    case 'history':
      renderHistory(data.messages);
      break;

    case 'session_renamed':
      refreshSessions();
      break;

    case 'directory_picked':
      handleDirectoryPicked(data.path);
      break;

    case 'directory_pick_cancelled':
      // User cancelled the native picker, do nothing
      break;

    case 'directory_pick_fallback':
      // OS not supported for native picker, use text input
      handleDirectoryFallback();
      break;

    case 'skills_list':
      state.skills = data.skills || [];
      state.skillsLoaded = true;
      break;

    case 'cmds_list':
      state.cmds = data.commands || [];
      state.cmdsLoaded = true;
      break;

    case 'mcp_list':
      state.mcpServers = data.servers || [];
      state.mcpLoaded = true;
      if (dom.mcpDropdown.style.display !== 'none') renderMcpDropdown();
      break;

    case 'models_list':
      state.models = data.models || [];
      state.modelsLoaded = true;
      if (data.current) state.currentModel = data.current;
      updateModelLabel();
      if (dom.modelDropdown.style.display !== 'none') renderModelDropdown();
      break;

    case 'error':
      appendErrorMessage(data.message);
      break;

    case 'system':
      if (data.subtype === 'compact_boundary') {
        appendSystemMsg('上下文已压缩');
      } else if (data.subtype === 'interrupted') {
        appendSystemMsg(data.message || '请求被中断');
      }
      break;

    default:
      // Ignore unknown message types
      break;
  }
}

function handleStatus(data) {
  switch (data.status) {
    case 'ready':
      state.isThinking = false;
      updateUIState();
      if (data.sessionId) {
        state.sessionId = data.sessionId;
      }
      if (data.cwd) state.cwd = data.cwd;
      break;

    case 'thinking':
      state.isThinking = true;
      updateUIState();
      showThinking();
      break;

    case 'done':
      state.isThinking = false;
      hideThinking();
      cleanupStreamingElements();
      updateUIState();
      break;

    case 'cancelled':
      state.isThinking = false;
      hideThinking();
      cleanupStreamingElements();
      updateUIState();
      appendSystemMsg('已中断');
      break;

    case 'interrupting':
      appendSystemMsg('正在中断...');
      break;

    case 'error':
      state.isThinking = false;
      hideThinking();
      updateUIState();
      break;

    case 'connected':
      break;
    case 'connecting':
      break;
  }
}

function updateUIState() {
  const hasCwd = !!state.cwd;

  // Always show input area + messages area
  dom.inputArea.style.display = 'block';
  dom.messages.style.display = 'flex';

  if (hasCwd) {
    dom.emptyState.style.display = 'none';
    const parts = state.cwd.split(/[/\\]/);
    dom.cwdName.textContent = parts[parts.length - 1] || state.cwd;
    dom.cwdFull.textContent = state.cwd;
    dom.sidebarSessionId.textContent = state.sessionId ? `会话: ${state.sessionId.slice(0, 5)}...` : '';
    document.title = (parts[parts.length - 1] || state.cwd) + ' — Agent花园·Code';
  } else {
    dom.emptyState.style.display = '';
    dom.cwdName.textContent = '';
    dom.cwdFull.textContent = '';
    dom.sidebarSessionId.textContent = '';
    document.title = 'Agent花园·Code WebUI';
  }

  if (state.isThinking) {
    dom.btnSend.style.display = 'none';
    dom.btnInterrupt.style.display = 'flex';
  } else {
    // Always show send button, let disabled state handle it
    dom.btnSend.style.display = 'flex';
    dom.btnSend.disabled = !hasCwd;
    dom.btnSend.style.opacity = hasCwd ? '1' : '0.4';
    dom.btnInterrupt.style.display = 'none';
  }
}

// ── Session list ─────────────────────────────────────────────────────────

function renderSessionList(groups) {
  // Restore refresh button & remove loading state
  dom.btnRefresh.textContent = '↻';
  dom.btnRefresh.disabled = false;
  dom.sessionList.classList.remove('loading');
  // Hide initial spinner
  const spinner = document.getElementById('session-list-spinner');
  if (spinner) spinner.style.display = 'none';

  if (!groups || groups.length === 0) {
    dom.sessionList.innerHTML = '';
    dom.sessionList.appendChild(dom.sessionEmpty);
    dom.sessionEmpty.style.display = 'block';
    return;
  }

  dom.sessionEmpty.style.display = 'none';
  state.sessionGroups = groups;
  state.sessions = groups.flatMap(g => g.sessions.map(s => ({ ...s, cwd: s.cwd || g.directory })));

  dom.sessionList.innerHTML = '';

  for (const group of groups) {
    const dir = group.directory;
    const isCollapsed = state.collapsedGroups[dir] !== false;

    const groupDiv = document.createElement('div');
    groupDiv.className = 'session-group';
    if (isCollapsed) groupDiv.classList.add('collapsed');

    // Collapsible header with chevron + folder icon + directory name
    const header = document.createElement('div');
    header.className = 'session-group-header';

    const chevron = document.createElement('span');
    chevron.className = 'session-group-chevron';
    chevron.textContent = isCollapsed ? '▶' : '▼';

    const icon = document.createElement('span');
    icon.className = 'session-group-icon';
    icon.textContent = '📁';

    const name = document.createElement('span');
    name.className = 'session-group-name';
    name.textContent = dir;
    name.title = dir;

    header.appendChild(chevron);
    header.appendChild(icon);
    header.appendChild(name);

    header.onclick = () => {
      const collapsed = groupDiv.classList.toggle('collapsed');
      chevron.textContent = collapsed ? '▶' : '▼';
      state.collapsedGroups[dir] = collapsed;
    };

    groupDiv.appendChild(header);

    // Session items body
    const body = document.createElement('div');
    body.className = 'session-group-body';

    for (const s of group.sessions) {
      const item = document.createElement('div');
      item.className = 'session-item';
      if (s.sessionId === state.sessionId) item.classList.add('active');

      const itemName = document.createElement('span');
      itemName.textContent = s.customTitle || s.summary || s.firstPrompt || '(无标题)';
      itemName.title = s.customTitle || s.summary || s.firstPrompt;
      itemName.style.flex = '1';
      itemName.style.overflow = 'hidden';
      itemName.style.textOverflow = 'ellipsis';
      item.appendChild(itemName);

      // Rename button → inline editing
      const actions = document.createElement('span');
      actions.className = 'session-actions';
      const renameBtn = document.createElement('button');
      renameBtn.className = 'btn-icon';
      renameBtn.textContent = '✎';
      renameBtn.title = '重命名';

      function startRename(e) {
        e.stopPropagation();
        const currentName = s.customTitle || s.summary || s.firstPrompt || '';
        // Replace name span with input
        const input = document.createElement('input');
        input.type = 'text';
        input.className = 'session-rename-input';
        input.value = currentName;
        item.replaceChild(input, itemName);

        // Replace ✎ with ✓ and ✗
        actions.innerHTML = '';
        const saveBtn = document.createElement('button');
        saveBtn.className = 'btn-icon btn-icon-save';
        saveBtn.textContent = '✓';
        saveBtn.title = '保存';
        const cancelBtn = document.createElement('button');
        cancelBtn.className = 'btn-icon btn-icon-cancel';
        cancelBtn.textContent = '✗';
        cancelBtn.title = '取消';

        function finishRename(save) {
          const newTitle = input.value.trim();
          if (save && newTitle && newTitle !== currentName) {
            send({ type: 'rename_session', sessionId: s.sessionId, title: newTitle });
            s.customTitle = newTitle;
            itemName.textContent = newTitle;
          }
          item.replaceChild(itemName, input);
          actions.innerHTML = '';
          actions.appendChild(renameBtn);
        }

        saveBtn.onclick = (ev) => { ev.stopPropagation(); finishRename(true); };
        cancelBtn.onclick = (ev) => { ev.stopPropagation(); finishRename(false); };
        input.addEventListener('keydown', (ev) => {
          ev.stopPropagation();
          if (ev.key === 'Enter' && !ev.isComposing) finishRename(true);
          if (ev.key === 'Escape') finishRename(false);
        });

        actions.appendChild(saveBtn);
        actions.appendChild(cancelBtn);
        input.focus();
        input.select();
      }

      renameBtn.onclick = startRename;
      actions.appendChild(renameBtn);
      item.appendChild(actions);

      item.onclick = () => {
        // Update active state
        $$('.session-item.active').forEach(el => el.classList.remove('active'));
        item.classList.add('active');

        // Clear messages & resume
        dom.messages.innerHTML = '';
        dom.permissionDialog.style.display = 'none';
        state.sessionId = s.sessionId;
        state.cwd = s.cwd;
        state.lastEchoedContent = null;
        updateUIState();

        send({ type: 'resume_session', sessionId: s.sessionId, directory: s.cwd });
      };

      body.appendChild(item);
    }

    groupDiv.appendChild(body);
    dom.sessionList.appendChild(groupDiv);
  }
}

function refreshSessions() {
  send({ type: 'get_sessions' });
}

// ── Messages ─────────────────────────────────────────────────────────────

function appendMessage(role, content, opts = {}) {
  const el = document.createElement('div');
  el.className = `message ${role}`;

  if (opts.label) {
    const label = document.createElement('div');
    label.className = 'msg-label';
    label.textContent = opts.label;
    el.appendChild(label);
  }

  if (typeof content === 'string') {
    el.innerHTML = formatContent(content);
  }

  dom.messages.appendChild(el);
  scrollToBottom();

  return el;
}

function appendAssistantMessage(data) {
  if (!data.content || data.content.length === 0) return;

  // Remove the streaming placeholder — this is the finalized version
  cleanupStreamingElements();

  const el = document.createElement('div');
  el.className = 'message claude';

  for (const block of data.content) {
    if (block.type === 'text') {
      const p = document.createElement('div');
      p.innerHTML = formatContent(block.text);
      el.appendChild(p);
    } else if (block.type === 'tool_use') {
      const tool = document.createElement('div');
      tool.className = 'tool-progress tool-complete';
      tool.innerHTML = `<span>🔧 ${escapeHtml(block.name)}</span>`;
      el.appendChild(tool);
    } else if (block.type === 'tool_result') {
      const result = document.createElement('div');
      result.className = 'tool-progress tool-complete';
      result.innerHTML = `<span>✓ 工具结果</span>`;
      if (block.content && typeof block.content === 'string' && block.content.length < 200) {
        result.innerHTML += `<pre>${escapeHtml(block.content)}</pre>`;
      }
      el.appendChild(result);
    }
  }

  // Only append if there's any visible content
  if (el.children.length > 0) {
    dom.messages.appendChild(el);
    scrollToBottom();
  }
}

function handleStreamEvent(data) {
  if (!data.event) return;

  // Find or create streaming message element
  let streamEl = dom.messages.querySelector('.message.claude.streaming');
  if (!streamEl) {
    streamEl = document.createElement('div');
    streamEl.className = 'message claude streaming';
    dom.messages.appendChild(streamEl);
  }

  const event = data.event;

  if (event.type === 'content_block_delta') {
    if (event.delta?.type === 'text_delta') {
      // Accumulate text — find or create text div
      let textDiv = streamEl.querySelector('.stream-text');
      if (!textDiv) {
        textDiv = document.createElement('div');
        textDiv.className = 'stream-text';
        streamEl.appendChild(textDiv);
      }
      textDiv.innerHTML += formatContent(event.delta.text);
    } else if (event.delta?.type === 'input_json_delta') {
      // Tool use JSON accumulation
      let toolDiv = streamEl.querySelector('.stream-tool-json');
      if (!toolDiv) {
        toolDiv = document.createElement('div');
        toolDiv.className = 'stream-tool-json tool-progress';
        streamEl.appendChild(toolDiv);
      }
      toolDiv.textContent += event.delta.partial_json || '';
    }
  } else if (event.type === 'content_block_start') {
    if (event.content_block?.type === 'tool_use') {
      let toolDiv = document.createElement('div');
      toolDiv.className = 'tool-progress';
      toolDiv.innerHTML = `<div class="tool-spinner"></div><span>🔧 ${escapeHtml(event.content_block.name)}</span>`;
      streamEl.appendChild(toolDiv);
    }
  } else if (event.type === 'content_block_stop') {
    // Content block complete
  } else if (event.type === 'message_delta') {
    // Handle stop reason etc.
  }

  if (data.ttft_ms && !streamEl.dataset.ttft) {
    streamEl.dataset.ttft = data.ttft_ms;
  }

  scrollToBottom();
}

function handleToolProgress(data) {
  // Update or create tool progress element
  const existing = dom.messages.querySelector(`.tool-progress[data-id="${data.tool_use_id}"]`);
  if (existing) {
    existing.innerHTML = `<div class="tool-spinner"></div><span>🔧 ${escapeHtml(data.tool_name)} (${data.elapsed_time_seconds.toFixed(1)}s)</span>`;
  } else {
    const el = document.createElement('div');
    el.className = 'tool-progress';
    el.dataset.id = data.tool_use_id;
    el.innerHTML = `<div class="tool-spinner"></div><span>🔧 ${escapeHtml(data.tool_name)} (${data.elapsed_time_seconds.toFixed(1)}s)</span>`;
    dom.messages.appendChild(el);
    scrollToBottom();
  }
}

function handleResult(data) {
  hideThinking();

  if (data.subtype === 'success') {
    // result handled
  } else if (data.subtype === 'error') {
    appendErrorMessage(data.result || '执行出错');
  }

  // Refresh sessions after completion
  setTimeout(refreshSessions, 500);
}

function stripCommandXml(text) {
  // SDK stores slash commands as <command-name>/x</command-name><command-message>x</command-message><command-args>...</command-args>
  const match = text.match(/^<command-name>([^<]+)<\/command-name>/);
  if (match) return match[1];
  return text;
}

function renderHistory(messages) {
  if (!messages || messages.length === 0) return;

  for (let i = 0; i < messages.length; i++) {
    const msg = messages[i];
    if (msg.type === 'user') {
      const content = msg.message?.content;
      let text = '';
      if (typeof content === 'string') {
        text = content;
      } else if (Array.isArray(content)) {
        text = content.filter(c => c.type === 'text').map(c => c.text).join('\n');
      }
      if (text) {
        text = stripCommandXml(text);
        if (text.includes('[Request interrupted by user')) {
          appendSystemMsg('请求已被用户中断');
        } else {
          appendMessage('user', text);
        }
      }
    } else if (msg.type === 'assistant') {
      const content = msg.message?.content || [];
      let text = '';
      for (const block of content) {
        if (block.type === 'text') text += block.text + '\n';
      }
      if (text.trim() && text.trim() !== 'No response requested.') {
        appendMessage('claude', text);
      }
    }
  }

  scrollToBottom();
}

// ── Thinking indicator ───────────────────────────────────────────────────

function showThinking() {
  hideThinking();
  const el = document.createElement('div');
  el.className = 'thinking';
  el.id = 'thinking-indicator';
  el.innerHTML = '<span>思考中</span><span class="dot"></span><span class="dot"></span><span class="dot"></span>';
  dom.messages.appendChild(el);
  scrollToBottom();
}

function hideThinking() {
  const el = document.getElementById('thinking-indicator');
  if (el) el.remove();
}

// ── Permission ───────────────────────────────────────────────────────────

let permState = { selectedIdx: 0, data: null };

function showPermissionRequest(data) {
  let riskClass = 'perm-risk-low';
  let icon = 'ℹ️';
  const toolName = data.toolName || '';

  if (toolName === 'Bash') { riskClass = 'perm-risk-high'; icon = '⚠️'; }
  else if (toolName === 'Edit' || toolName === 'Write' || toolName === 'NotebookEdit') { riskClass = 'perm-risk-medium'; icon = '✏️'; }
  else if (toolName === 'Read') { riskClass = 'perm-risk-low'; icon = '📖'; }

  dom.permIcon.textContent = icon;
  dom.permTitle.textContent = data.displayName || data.title || `确认执行 ${toolName}`;
  dom.permissionDialog.querySelector('.perm-card').className = `perm-card ${riskClass}`;

  let body = '<div class="perm-detail">';
  if (data.description) {
    body += `<p class="perm-desc">${formatContent(preprocessPermText(data.description))}</p>`;
  }
  // Show command for tools that have one (Bash, etc.)
  const cmd = data.input?.command;
  if (cmd) {
    body += `<div class="perm-command">${escapeHtml(cmd)}</div>`;
  }
  if (data.input?.file_path || data.blockedPath) {
    body += `<p class="perm-path">📄 ${escapeHtml(data.input?.file_path || data.blockedPath)}</p>`;
  }
  if (data.decisionReason) {
    body += `<p class="perm-reason">${escapeHtml(translatePermText(data.decisionReason))}</p>`;
  }
  body += '</div>';
  dom.permBody.innerHTML = body;

  // Set the tool label for "don't ask again"
  dom.permToolLabel.textContent = toolName;

  // Reset selection
  permState = { selectedIdx: 0, data };
  updatePermSelection();

  dom.permissionDialog.style.display = 'block';
  // Focus to enable keyboard
  dom.permissionDialog.focus();
}

function translatePermText(text) {
  if (!text) return text;
  const translations = [
    [/This command requires approval/gi, '此命令需要授权'],
    [/This tool requires approval/gi, '此工具需要授权'],
    [/This file operation requires approval/gi, '此文件操作需要授权'],
    [/Requires approval/gi, '需要授权'],
  ];
  for (const [regex, replacement] of translations) {
    text = text.replace(regex, replacement);
  }
  return text;
}

function preprocessPermText(text) {
  if (!text) return text;
  // Translate English phrases
  text = translatePermText(text);
  // Detect command-like lines and wrap in backticks for code rendering
  text = text.replace(/^(.+)$/gm, (match) => {
    const trimmed = match.trim();
    if (!trimmed) return match;
    // Skip if already wrapped in backticks
    if (trimmed.startsWith('`')) return match;
    // Skip lines starting with CJK characters (not commands)
    if (/^[一-鿿　-〿＀-￯]/.test(trimmed)) return match;
    // Command detection heuristics
    const firstWord = trimmed.split(/\s/)[0];
    // First word contains _ - . / (system_profiler, git-log, ./script.sh)
    if (/[_.\-\/]/.test(firstWord) && /^[a-zA-Z]/.test(firstWord)) return '`' + match + '`';
    // Common CLI commands (conda, pip, npm, python, node, git, etc.)
    if (/^(conda|pip|pip3|npm|npx|yarn|pnpm|bun|deno|python|python3|node|ruby|java|go|cargo|make|cmake|gcc|g\+\+|docker|kubectl|git|brew|apt|yum|dnf|sudo|su|ssh|scp|curl|wget|tar|unzip|chmod|chown|cp|mv|rm|mkdir|cat|echo|touch|ls|find|grep|sed|awk|head|tail|sort|wc|diff|patch)(\s|$)/.test(trimmed)) return '`' + match + '`';
    // Contains command chaining operators (&& || | ;)
    if (/&&|\|\||[|;]/.test(trimmed)) return '`' + match + '`';
    // Contains shell flags (-x or --xxx) preceded by space
    if (/\s-{1,2}[a-zA-Z]/.test(trimmed)) return '`' + match + '`';
    // Starts with a word and contains a path pattern (/xxx/)
    if (/^[a-zA-Z]\w*\s.*\/[\w]/.test(trimmed)) return '`' + match + '`';
    return match;
  });
  return text;
}

function updatePermSelection() {
  const options = dom.permOptions.querySelectorAll('.perm-option');
  options.forEach((opt, i) => {
    opt.classList.toggle('selected', i === permState.selectedIdx);
    opt.querySelector('.perm-option-marker').textContent = i === permState.selectedIdx ? '❯' : ' ';
  });
}

function confirmPermOption(action, toolUseID, toolName) {
  switch (action) {
    case 'allow':
      send({ type: 'permission_response', toolUseID, granted: true });
      break;
    case 'persist':
      send({ type: 'permission_response', toolUseID, granted: true, persistent: true, toolName });
      break;
    case 'deny':
      send({ type: 'permission_response', toolUseID, granted: false });
      break;
  }
  hidePermissionDialog();
}

function hidePermissionDialog() {
  dom.permissionDialog.style.display = 'none';
  permState.data = null;
}

// Permission option click handlers
dom.permOptions.addEventListener('click', (e) => {
  const opt = e.target.closest('.perm-option');
  if (!opt || !permState.data) return;
  confirmPermOption(opt.dataset.action, permState.data.toolUseID, permState.data.toolName);
});

// Keyboard navigation for permission dialog
document.addEventListener('keydown', (e) => {
  if (!permState.data) return;

  if (e.key === 'ArrowDown' || e.key === 'ArrowUp') {
    e.preventDefault();
    const count = dom.permOptions.querySelectorAll('.perm-option').length;
    if (e.key === 'ArrowDown') {
      permState.selectedIdx = (permState.selectedIdx + 1) % count;
    } else {
      permState.selectedIdx = (permState.selectedIdx - 1 + count) % count;
    }
    updatePermSelection();
  } else if (e.key === 'Enter') {
    e.preventDefault();
    const options = dom.permOptions.querySelectorAll('.perm-option');
    const selected = options[permState.selectedIdx];
    if (selected) {
      confirmPermOption(selected.dataset.action, permState.data.toolUseID, permState.data.toolName);
    }
  }
});

// ── Utility messages ─────────────────────────────────────────────────────

function appendSystemMsg(text) {
  const el = document.createElement('div');
  el.className = 'system-msg';
  el.textContent = text;
  dom.messages.appendChild(el);
  scrollToBottom();
}

function appendErrorMessage(text) {
  const el = document.createElement('div');
  el.className = 'error-msg';
  el.textContent = text;
  dom.messages.appendChild(el);
  scrollToBottom();
}

// ── Content formatting ───────────────────────────────────────────────────

function formatContent(text) {
  // Phase 1: Split into code-fence and text segments
  const segments = [];
  const fenceRegex = /```(\w*)\n([\s\S]*?)```/g;
  let lastIdx = 0;
  let match;

  while ((match = fenceRegex.exec(text)) !== null) {
    if (match.index > lastIdx) {
      segments.push({ type: 'text', content: text.slice(lastIdx, match.index) });
    }
    segments.push({ type: 'code', lang: match[1], code: match[2].trim() });
    lastIdx = fenceRegex.lastIndex;
  }
  if (lastIdx < text.length) {
    segments.push({ type: 'text', content: text.slice(lastIdx) });
  }

  // Phase 2: Render each segment
  return segments.map(seg => {
    if (seg.type === 'code') {
      return `<pre><code class="language-${escapeHtml(seg.lang)}">${escapeHtml(seg.code)}</code></pre>`;
    }
    return formatTextSegment(seg.content);
  }).join('');
}

function formatTextSegment(text) {
  let html = escapeHtml(text);

  // Block-level: headers (must run before inline in case of # in code)
  html = html.replace(/^### (.+)$/gm, '<h3>$1</h3>');
  html = html.replace(/^## (.+)$/gm, '<h2>$1</h2>');
  html = html.replace(/^# (.+)$/gm, '<h1>$1</h1>');

  // Block-level: unordered lists (consecutive lines starting with - or *)
  html = html.replace(/((?:^[-*] .+$\n?)+)/gm, (list) => {
    const items = list.trim().split('\n').map(line =>
      `<li>${line.replace(/^[-*] /, '')}</li>`
    ).join('');
    return `<ul>${items}</ul>`;
  });

  // Block-level: ordered lists (consecutive lines starting with N.)
  html = html.replace(/((?:^\d+\. .+$\n?)+)/gm, (list) => {
    const items = list.trim().split('\n').map(line =>
      `<li>${line.replace(/^\d+\. /, '')}</li>`
    ).join('');
    return `<ol>${items}</ol>`;
  });

  // Block-level: blockquotes
  html = html.replace(/^&gt; (.+)$/gm, '<blockquote>$1</blockquote>');

  // Block-level: tables (consecutive lines with | separators)
  html = html.replace(/((?:^\|.+\|$\n?)+)/gm, (tableBlock) => {
    const lines = tableBlock.trim().split('\n');
    if (lines.length < 2) return tableBlock;
    const hasHeader = /^[\|\s\-:]+\|?$/.test(lines[1]);
    let result = '<table>';
    for (let i = 0; i < lines.length; i++) {
      if (/^[\|\s\-:]+\|?$/.test(lines[i])) continue;
      // Split on | that is NOT preceded by \
      const raw = lines[i].replace(/^[\|\s]+|[\|\s]+$/g, '');
      const cells = raw.split(/(?<!\\)\|/).map(c => c.trim().replace(/\\\|/g, '|'));
      result += '<tr>';
      const tag = (hasHeader && i === 0) ? 'th' : 'td';
      for (const cell of cells) {
        result += `<${tag}>${cell || ''}</${tag}>`;
      }
      result += '</tr>';
    }
    result += '</table>';
    return result;
  });

  // Inline: bold **text**
  html = html.replace(/\*\*([^*]+)\*\*/g, '<strong>$1</strong>');

  // Inline: italic *text* (single asterisks, not inside **)
  html = html.replace(/(?<!\*)\*([^*]+)\*(?!\*)/g, '<em>$1</em>');

  // Inline: code `text`
  html = html.replace(/`([^`]+)`/g, '<code>$1</code>');

  // Inline: links [text](url)
  html = html.replace(/\[([^\]]+)\]\(([^)]+)\)/g, '<a href="$2" target="_blank" rel="noopener">$1</a>');

  // Remaining newlines → <br> (skip if already inside block tags)
  html = html.replace(/\n\n/g, '<br><br>');
  html = html.replace(/\n/g, '<br>');

  return html;
}

function escapeHtml(text) {
  const div = document.createElement('div');
  div.textContent = text;
  return div.innerHTML;
}

// ── Stream cleanup ────────────────────────────────────────────────────────

function cleanupStreamingElements() {
  dom.messages.querySelectorAll('.message.claude.streaming').forEach(el => el.remove());
}

// ── Scroll ───────────────────────────────────────────────────────────────

function scrollToBottom() {
  requestAnimationFrame(() => {
    dom.messages.scrollTop = dom.messages.scrollHeight;
  });
}

// ── Input handling ───────────────────────────────────────────────────────

dom.userInput.addEventListener('keydown', (e) => {
  if (e.key === 'Enter' && !e.shiftKey && !e.isComposing) {
    e.preventDefault();
    sendMessage();
  }
  // Backspace on empty input removes last skill chip
  if (e.key === 'Backspace' && dom.userInput.value === '' && state.activeSkills.length > 0) {
    removeSkillChip(state.activeSkills[state.activeSkills.length - 1]);
  }
});

dom.btnSend.addEventListener('click', sendMessage);

dom.btnInterrupt.addEventListener('click', () => {
  send({ type: 'interrupt' });
});

function sendMessage() {
  const text = dom.userInput.value.trim();
  if (!text && state.activeSkills.length === 0) return;
  if (state.isThinking) return;
  if (!state.cwd) return;

  dom.userInput.value = '';
  dom.userInput.style.height = 'auto';

  // Build full text with skill prefix
  const prefix = state.activeSkills.map(s => '/' + s).join(' ');
  const fullText = prefix + (prefix && text ? ' ' : '') + text;

  // Clear skill chips
  state.activeSkills = [];
  dom.skillChips.innerHTML = '';

  send({ type: 'user_input', content: fullText });
}

// Auto-resize textarea
dom.userInput.addEventListener('input', () => {
  dom.userInput.style.height = 'auto';
  dom.userInput.style.height = Math.min(dom.userInput.scrollHeight, 150) + 'px';
});

// ── Directory validation utility ───────────────────────────────────────────

async function checkDirectory(val) {
  if (!val || !val.trim()) return null;
  try {
    const resp = await fetch(`/api/check-directory?path=${encodeURIComponent(val)}`);
    const result = await resp.json();
    if (result.valid) {
      state.cwd = result.path;
      updateUIState();
      return result.path;
    }
  } catch {}
  return null;
}

// ── New session ──────────────────────────────────────────────────────────

dom.btnNew.addEventListener('click', () => {
  if (!state.cwd) {
    appendErrorMessage('请先通过 📂 按钮选择工作目录');
    return;
  }

  // Clear UI
  dom.messages.innerHTML = '';
  dom.permissionDialog.style.display = 'none';
  state.sessionId = null;
  state.lastEchoedContent = null;
  updateUIState();

  // Send create session
  send({ type: 'create_session', directory: state.cwd, permissionMode: 'default' });

  appendSystemMsg(`新会话 — ${state.cwd}`);
});

// ── Refresh button ────────────────────────────────────────────────────────

dom.btnRefresh.addEventListener('click', () => {
  dom.btnRefresh.textContent = '⏳';
  dom.btnRefresh.disabled = true;
  dom.sessionList.classList.add('loading');
  send({ type: 'get_sessions' });
});

// ── Folder picker ─────────────────────────────────────────────────────────

dom.btnPickDir.addEventListener('click', () => {
  // Request server to show native directory picker (no confirmation dialog)
  send({ type: 'pick_directory' });
});

async function handleDirectoryPicked(path) {
  if (!path) return;
  const validPath = await checkDirectory(path);
  if (validPath) {
    // Clear current messages and create new session
    dom.messages.innerHTML = '';
    dom.permissionDialog.style.display = 'none';
    state.sessionId = null;
    state.lastEchoedContent = null;
    updateUIState();
    send({ type: 'create_session', directory: state.cwd, permissionMode: 'default' });
    appendSystemMsg(`新会话 — ${state.cwd}`);
  } else {
    appendErrorMessage(`目录无效: ${path}`);
  }
}

function handleDirectoryFallback() {
  // Fallback for unsupported OS: plain text input
  const path = prompt('输入项目目录完整路径:', state.cwd || '');
  if (path) handleDirectoryPicked(path);
}

// Click the path bubble to edit the cwd manually

// ── Built-in commands selector ──────────────────────────────────────────────

const CMD_DESCRIPTIONS = {
  // Built-in commands
  'clear': '清除对话历史',
  'compact': '压缩对话上下文',
  'usage': '查看使用统计',
  'init': '初始化项目 CLAUDE.md',
  'review': '代码审查',
  // Bundled skills
  'update-config': '配置 Claude Code 设置',
  'debug': '调试代码问题',
  'simplify': '审查并简化代码',
  'batch': '批量处理任务',
  'fewer-permission-prompts': '减少权限提示',
  'loop': '循环定时执行命令',
  'claude-api': 'Claude API 开发辅助',
  'context': '管理上下文',
  'heapdump': '导出堆快照',
  'security-review': '安全审查',
  'insights': '查看洞察分析',
  'team-onboarding': '团队入门引导',
};

dom.btnCmds.addEventListener('click', (e) => {
  e.stopPropagation();
  const visible = dom.cmdsDropdown.style.display !== 'none';
  if (visible) {
    dom.cmdsDropdown.style.display = 'none';
    return;
  }
  // Close other dropdowns
  dom.skillsDropdown.style.display = 'none';
  dom.mcpDropdown.style.display = 'none';
  dom.modelDropdown.style.display = 'none';
  renderCmdsDropdown();
  dom.cmdsDropdown.style.display = 'block';
});

function renderCmdsDropdown() {
  dom.cmdsList.innerHTML = '';
  if (state.cmds.length === 0) {
    dom.cmdsEmpty.textContent = state.cmdsLoaded ? '暂无可用命令' : '发送一条消息后可查看可用命令';
    dom.cmdsEmpty.style.display = 'block';
    return;
  }
  dom.cmdsEmpty.style.display = 'none';
  for (const name of state.cmds) {
    const item = document.createElement('div');
    item.className = 'cmds-dropdown-item';
    const nameEl = document.createElement('span');
    nameEl.className = 'cmds-dropdown-name';
    nameEl.textContent = '/' + name;
    const descEl = document.createElement('span');
    descEl.className = 'cmds-dropdown-desc';
    descEl.textContent = CMD_DESCRIPTIONS[name] || '';
    item.appendChild(nameEl);
    item.appendChild(descEl);
    item.onclick = () => {
      dom.cmdsDropdown.style.display = 'none';
      send({ type: 'user_input', content: '/' + name });
    };
    dom.cmdsList.appendChild(item);
  }
}

// ── Skill selector ────────────────────────────────────────────────────────

dom.btnSkills.addEventListener('click', (e) => {
  e.stopPropagation();
  const visible = dom.skillsDropdown.style.display !== 'none';
  if (visible) {
    dom.skillsDropdown.style.display = 'none';
    return;
  }
  // Close other dropdowns
  dom.cmdsDropdown.style.display = 'none';
  dom.mcpDropdown.style.display = 'none';
  dom.modelDropdown.style.display = 'none';
  renderSkillsDropdown();
  dom.skillsDropdown.style.display = 'block';
});

// Close dropdowns on outside click
document.addEventListener('click', (e) => {
  if (!dom.cmdsDropdown.contains(e.target) && e.target !== dom.btnCmds) {
    dom.cmdsDropdown.style.display = 'none';
  }
  if (!dom.skillsDropdown.contains(e.target) && e.target !== dom.btnSkills) {
    dom.skillsDropdown.style.display = 'none';
  }
  if (!dom.mcpDropdown.contains(e.target) && e.target !== dom.btnMcp) {
    dom.mcpDropdown.style.display = 'none';
  }
  if (!dom.modelDropdown.contains(e.target) && e.target !== dom.btnModel) {
    dom.modelDropdown.style.display = 'none';
  }
});

function renderSkillsDropdown() {
  dom.skillsList.innerHTML = '';
  if (state.skills.length === 0) {
    dom.skillsEmpty.textContent = state.skillsLoaded ? '暂无可用的 Skill' : '发送一条消息后可查看可用 Skill';
    dom.skillsEmpty.style.display = 'block';
    return;
  }
  dom.skillsEmpty.style.display = 'none';
  for (const skill of state.skills) {
    const item = document.createElement('div');
    item.className = 'skills-dropdown-item';
    const name = document.createElement('span');
    name.className = 'skills-dropdown-name';
    name.textContent = skill.name;
    const desc = document.createElement('span');
    desc.className = 'skills-dropdown-desc';
    desc.textContent = skill.description || '';
    item.appendChild(name);
    item.appendChild(desc);
    item.onclick = () => {
      addSkillChip(skill.name);
      dom.skillsDropdown.style.display = 'none';
      dom.userInput.focus();
    };
    dom.skillsList.appendChild(item);
  }
}

function addSkillChip(name) {
  // Claude Code only supports one skill at a time
  state.activeSkills = [name];
  dom.skillChips.innerHTML = '';
  const chip = document.createElement('span');
  chip.className = 'skill-chip';
  chip.dataset.skill = name;
  chip.innerHTML = `<span class="skill-chip-name">${escapeHtml(name)}</span><span class="skill-chip-remove">✗</span>`;
  chip.querySelector('.skill-chip-remove').onclick = () => removeSkillChip(name);
  dom.skillChips.appendChild(chip);
}

function removeSkillChip(name) {
  state.activeSkills = state.activeSkills.filter(s => s !== name);
  const chip = dom.skillChips.querySelector(`[data-skill="${name}"]`);
  if (chip) chip.remove();
}

// ── MCP selector ────────────────────────────────────────────────────────

dom.btnMcp.addEventListener('click', (e) => {
  e.stopPropagation();
  const visible = dom.mcpDropdown.style.display !== 'none';
  if (visible) {
    dom.mcpDropdown.style.display = 'none';
    return;
  }
  // Close other dropdowns
  dom.cmdsDropdown.style.display = 'none';
  dom.skillsDropdown.style.display = 'none';
  dom.modelDropdown.style.display = 'none';
  renderMcpDropdown();
  dom.mcpDropdown.style.display = 'block';
});

function renderMcpDropdown() {
  dom.mcpList.innerHTML = '';
  if (state.mcpServers.length === 0) {
    dom.mcpEmpty.textContent = state.mcpLoaded ? '暂无 MCP 服务器' : '发送一条消息后可查看 MCP 服务器';
    dom.mcpEmpty.style.display = 'block';
    return;
  }
  dom.mcpEmpty.style.display = 'none';
  for (const server of state.mcpServers) {
    const item = document.createElement('div');
    item.className = 'mcp-item';

    // Status dot
    const dot = document.createElement('span');
    dot.className = 'mcp-status-dot ' + (server.status || 'pending');

    // Info
    const info = document.createElement('div');
    info.className = 'mcp-info';
    const nameEl = document.createElement('div');
    nameEl.className = 'mcp-name';
    nameEl.textContent = server.name;
    info.appendChild(nameEl);
    if (server.tools && server.tools.length > 0) {
      const toolsEl = document.createElement('div');
      toolsEl.className = 'mcp-tools-count';
      toolsEl.textContent = server.tools.length + ' 个工具';
      info.appendChild(toolsEl);
    }
    if (server.error) {
      const errEl = document.createElement('div');
      errEl.className = 'mcp-tools-count';
      errEl.style.color = 'var(--danger)';
      errEl.textContent = server.error;
      info.appendChild(errEl);
    }

    // Actions
    const actions = document.createElement('div');
    actions.className = 'mcp-actions';

    // Toggle button
    const toggleBtn = document.createElement('button');
    toggleBtn.className = 'mcp-btn' + (server.status !== 'disabled' ? ' active' : '');
    toggleBtn.textContent = server.status !== 'disabled' ? 'ON' : 'OFF';
    toggleBtn.onclick = (e) => {
      e.stopPropagation();
      const enable = server.status === 'disabled';
      send({ type: 'mcp_toggle', serverName: server.name, enabled: enable });
    };
    actions.appendChild(toggleBtn);

    // Reconnect button (only for failed servers)
    if (server.status === 'failed') {
      const reconnectBtn = document.createElement('button');
      reconnectBtn.className = 'mcp-btn reconnect';
      reconnectBtn.textContent = '重连';
      reconnectBtn.onclick = (e) => {
        e.stopPropagation();
        send({ type: 'mcp_reconnect', serverName: server.name });
      };
      actions.appendChild(reconnectBtn);
    }

    item.appendChild(dot);
    item.appendChild(info);
    item.appendChild(actions);
    dom.mcpList.appendChild(item);
  }
}

// ── Model selector ─────────────────────────────────────────────────────

function updateModelLabel() {
  if (state.currentModel && state.models.length > 0) {
    const match = state.models.find(m => m.value === state.currentModel);
    dom.modelLabel.textContent = match ? match.displayName : state.currentModel;
  } else {
    dom.modelLabel.textContent = '模型';
  }
}

dom.btnModel.addEventListener('click', (e) => {
  e.stopPropagation();
  const visible = dom.modelDropdown.style.display !== 'none';
  if (visible) {
    dom.modelDropdown.style.display = 'none';
    return;
  }
  dom.cmdsDropdown.style.display = 'none';
  dom.skillsDropdown.style.display = 'none';
  dom.mcpDropdown.style.display = 'none';
  renderModelDropdown();
  dom.modelDropdown.style.display = 'block';
});

function renderModelDropdown() {
  dom.modelList.innerHTML = '';
  if (state.models.length === 0) {
    dom.modelEmpty.textContent = state.modelsLoaded ? '暂无可用模型' : '发送一条消息后可查看可用模型';
    dom.modelEmpty.style.display = 'block';
    return;
  }
  dom.modelEmpty.style.display = 'none';
  for (const model of state.models) {
    const item = document.createElement('div');
    item.className = 'model-item' + (model.value === state.currentModel ? ' active' : '');
    const name = document.createElement('span');
    name.className = 'model-name';
    name.textContent = model.displayName;
    const desc = document.createElement('span');
    desc.className = 'model-desc';
    desc.textContent = model.description || '';
    item.appendChild(name);
    item.appendChild(desc);
    if (model.value === state.currentModel) {
      const check = document.createElement('span');
      check.className = 'model-check';
      check.textContent = '✓';
      item.appendChild(check);
    }
    item.onclick = () => {
      if (model.value === state.currentModel) {
        dom.modelDropdown.style.display = 'none';
        return;
      }
      state.currentModel = model.value;
      updateModelLabel();
      dom.modelDropdown.style.display = 'none';
      send({ type: 'model_set', model: model.value });
    };
    dom.modelList.appendChild(item);
  }
}

// ── Resize handle ─────────────────────────────────────────────────────────

const resizeHandle = document.getElementById('resize-handle');
const sidebar = document.getElementById('sidebar');
let isResizing = false;
let resizeStartX = 0;
let resizeStartW = 0;

resizeHandle.addEventListener('mousedown', (e) => {
  isResizing = true;
  resizeStartX = e.clientX;
  resizeStartW = sidebar.offsetWidth;
  resizeHandle.classList.add('active');
  document.body.style.cursor = 'col-resize';
  document.body.style.userSelect = 'none';
  e.preventDefault();
});

document.addEventListener('mousemove', (e) => {
  if (!isResizing) return;
  const delta = e.clientX - resizeStartX;
  let newW = resizeStartW + delta;
  const maxW = Math.floor(window.innerWidth * 0.5);
  newW = Math.max(0, Math.min(maxW, newW));
  sidebar.style.width = newW + 'px';
  sidebar.style.overflow = newW < 30 ? 'hidden' : '';
});

document.addEventListener('mouseup', () => {
  if (!isResizing) return;
  isResizing = false;
  resizeHandle.classList.remove('active');
  document.body.style.cursor = '';
  document.body.style.userSelect = '';
  // Save to CSS variable
  document.documentElement.style.setProperty('--sidebar-w', sidebar.style.width);
});

// ── Init ─────────────────────────────────────────────────────────────────

// Expose internals for demo automation
Object.defineProperty(window, '__ws', { get: () => ws });
Object.defineProperty(window, '__state', { get: () => state });
window.__handleDirectoryPicked = handleDirectoryPicked;

connect();
updateUIState();
