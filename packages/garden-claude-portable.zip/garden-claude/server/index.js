import { createServer } from 'node:http';
import { statSync, existsSync, readFileSync } from 'node:fs';
import { normalize, join, resolve, extname, sep } from 'node:path';
import { fileURLToPath } from 'node:url';
import { WebSocketServer } from 'ws';
import { handleConnection } from './ws-handler.js';

function getFrontendDir() {
  const mode = process.env.GARDEN_MODE || '';
  return mode === 'basic'
    ? resolve(join(fileURLToPath(import.meta.url), '../../frontend-lite'))
    : resolve(join(fileURLToPath(import.meta.url), '../../frontend'));
}
const MIME_TYPES = {
  '.html': 'text/html; charset=utf-8',
  '.css': 'text/css; charset=utf-8',
  '.js': 'text/javascript; charset=utf-8',
  '.svg': 'image/svg+xml',
  '.png': 'image/png',
  '.ico': 'image/x-icon',
};

// ── Static file serving with path traversal protection ────────────────

function serveStatic(req, res) {
  let { pathname } = new URL(req.url, `http://${req.headers.host}`);
  if (pathname === '/') pathname = '/index.html';

  // Decode percent-encoded characters (e.g. %2e → ., %2f → /)
  let decoded;
  try {
    decoded = decodeURIComponent(pathname);
  } catch {
    // Malformed URI — reject
    res.writeHead(400, { 'Content-Type': 'text/plain; charset=utf-8' });
    res.end('Bad Request');
    return;
  }

  // Strip leading slash so path.join treats it as a relative segment
  const relativePath = decoded.startsWith('/') ? decoded.slice(1) : decoded;
  const safePath = normalize(join(getFrontendDir(), relativePath));

  // Block path traversal: resolved path must stay within getFrontendDir()
  if (!safePath.startsWith(getFrontendDir() + sep) && safePath !== getFrontendDir()) {
    res.writeHead(403, { 'Content-Type': 'text/plain; charset=utf-8' });
    res.end('Forbidden');
    return;
  }

  try {
    if (!existsSync(safePath) || !statSync(safePath).isFile()) {
      // Fall back to index.html for SPA routing
      const indexFallback = join(getFrontendDir(), 'index.html');
      if (existsSync(indexFallback) && statSync(indexFallback).isFile()) {
        const content = readFileSync(indexFallback, 'utf-8');
        res.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8' });
        res.end(content);
        return;
      }
      res.writeHead(404, { 'Content-Type': 'text/plain; charset=utf-8' });
      res.end('Not Found');
      return;
    }

    const ext = extname(safePath);
    const contentType = MIME_TYPES[ext] || 'application/octet-stream';
    const content = readFileSync(safePath, 'utf-8');
    res.writeHead(200, { 'Content-Type': contentType });
    res.end(content);
  } catch (err) {
    res.writeHead(500, { 'Content-Type': 'text/plain; charset=utf-8' });
    res.end('Internal Server Error');
  }
}

// ── Directory validation API ───────────────────────────────────────────

function validateDirectory(input) {
  if (!input || !input.trim()) {
    return { valid: false, error: '请输入目录路径' };
  }
  const resolved = resolve(normalize(input.trim()));
  if (!existsSync(resolved)) {
    return { valid: false, error: `路径不存在: ${resolved}` };
  }
  if (!statSync(resolved).isDirectory()) {
    return { valid: false, error: `不是目录: ${resolved}` };
  }
  return { valid: true, path: resolved };
}

function apiCheckDirectory(req, res) {
  const url = new URL(req.url, `http://${req.headers.host}`);
  const path = url.searchParams.get('path');
  const result = validateDirectory(path);
  res.writeHead(200, { 'Content-Type': 'application/json; charset=utf-8' });
  res.end(JSON.stringify(result));
}

// ── Server startup ─────────────────────────────────────────────────────

export function startServer(port, onReady) {
  const server = createServer((req, res) => {
    try {
      if (req.method === 'GET' && req.url?.startsWith('/api/check-directory')) {
        return apiCheckDirectory(req, res);
      }
      if (req.method === 'GET') {
        return serveStatic(req, res);
      }
      res.writeHead(405, { 'Content-Type': 'text/plain; charset=utf-8' });
      res.end('Method Not Allowed');
    } catch (err) {
      res.writeHead(500, { 'Content-Type': 'text/plain; charset=utf-8' });
      res.end('Internal Server Error');
    }
  });

  const wss = new WebSocketServer({ server });

  wss.on('connection', (ws) => {
    handleConnection(ws);
  });

  server.listen(port, () => {
    console.log(`✓ cc-webui 已启动 → http://localhost:${port}`);
    onReady?.(port, server);
  });

  return server;
}
