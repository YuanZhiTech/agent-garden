import { createQuery, listSessionsForDir, getSessionHistory, renameSessionTitle } from './claude-service.js';
import { execFile, exec } from 'node:child_process';
import { platform, homedir } from 'node:os';
import { readdirSync } from 'node:fs';
import { join } from 'node:path';

const PERMISSION_TIMEOUT_MS = 5 * 60 * 1000; // 5 minutes

// ── User-level skill detection ─────────────────────────────────────────

function getUserSkillNames() {
  const dir = join(homedir(), '.claude', 'commands');
  try {
    return new Set(
      readdirSync(dir)
        .filter(f => f.endsWith('.md'))
        .map(f => f.slice(0, -3))
    );
  } catch {
    return new Set();
  }
}

/**
 * Handle a new WebSocket connection.
 * @param {import('ws').WebSocket} ws
 */
export function handleConnection(ws) {
  const state = {
    cwd: null,
    sessionId: null,
    abortController: null,
    activeQuery: null,
    permissionMode: 'default',
    currentModel: null,
    allowedTools: new Set(), // tools the user has permanently allowed
    pendingPermissions: new Map(), // toolUseID → { resolve, reject, timer }
  };

  console.log('[ws] 新连接');

  send(ws, { type: 'status', status: 'connected' });

  ws.on('message', (raw) => {
    let data;
    try {
      data = JSON.parse(raw.toString());
    } catch {
      send(ws, { type: 'error', message: '无效的 JSON' });
      return;
    }

    handleMessage(ws, state, data).catch((err) => {
      console.error('[ws] 消息处理错误:', err);
      send(ws, { type: 'error', message: err.message || '服务器内部错误' });
    });
  });

  ws.on('close', () => {
    console.log('[ws] 连接关闭');
    cleanup(state);
  });

  ws.on('error', (err) => {
    console.error('[ws] 连接错误:', err.message);
    cleanup(state);
  });
}

function send(ws, msg) {
  if (ws.readyState === ws.OPEN) {
    ws.send(JSON.stringify(msg));
  }
}

function cleanup(state) {
  // Clear all pending permissions
  for (const [id, { resolve, timer }] of state.pendingPermissions) {
    clearTimeout(timer);
    resolve({ behavior: 'deny', message: '连接已断开' });
  }
  state.pendingPermissions.clear();

  // Interrupt and abort active query
  if (state.activeQuery) {
    try { state.activeQuery.interrupt(); } catch {}
  }
  if (state.abortController) {
    try { state.abortController.abort(); } catch {}
  }
  state.activeQuery = null;
  state.abortController = null;
}

async function handleMessage(ws, state, data) {
  switch (data.type) {
    case 'get_sessions':
      await handleGetSessions(ws, state, data);
      break;

    case 'create_session':
      await handleCreateSession(ws, state, data);
      break;

    case 'resume_session':
      await handleResumeSession(ws, state, data);
      break;

    case 'user_input':
      await handleUserInput(ws, state, data);
      break;

    case 'interrupt':
      handleInterrupt(ws, state);
      break;

    case 'permission_response':
      handlePermissionResponse(ws, state, data);
      break;

    case 'rename_session':
      await handleRenameSession(ws, state, data);
      break;

    case 'pick_directory':
      await handlePickDirectory(ws, state);
      break;

    case 'mcp_status':
      await handleMcpStatus(ws, state);
      break;

    case 'mcp_toggle':
      await handleMcpToggle(ws, state, data);
      break;

    case 'mcp_reconnect':
      await handleMcpReconnect(ws, state, data);
      break;

    case 'model_set':
      await handleModelSet(ws, state, data);
      break;

    default:
      send(ws, { type: 'error', message: `未知消息类型: ${data.type}` });
  }
}

// ── Session listing ────────────────────────────────────────────────────

async function handleGetSessions(ws, state, data) {
  try {
    const sessions = await listSessionsForDir(data.directory);

    // Group sessions by cwd
    const grouped = new Map();
    for (const s of sessions) {
      const dir = s.cwd || '(未知目录)';
      if (!grouped.has(dir)) grouped.set(dir, []);
      grouped.get(dir).push({
        sessionId: s.sessionId,
        summary: s.summary || s.customTitle || s.firstPrompt || '(无标题)',
        customTitle: s.customTitle,
        lastModified: s.lastModified,
        firstPrompt: s.firstPrompt,
        gitBranch: s.gitBranch,
        cwd: s.cwd,
      });
    }

    const groups = [];
    for (const [dir, items] of grouped) {
      groups.push({ directory: dir, sessions: items });
    }

    send(ws, { type: 'session_list', groups });
  } catch (err) {
    console.error('[ws] 获取会话列表失败:', err);
    send(ws, { type: 'error', message: '获取会话列表失败: ' + err.message });
  }
}

// ── Session creation / resume ──────────────────────────────────────────

async function handleCreateSession(ws, state, data) {
  // Validate directory
  const { directory } = data;
  if (!directory) {
    send(ws, { type: 'error', message: '请指定工作目录' });
    return;
  }

  // Interrupt any active query
  await interruptActive(state);

  state.cwd = directory;
  state.sessionId = null;
  state.allowedTools.clear();
  state.permissionMode = data.permissionMode || 'default';

  send(ws, { type: 'status', status: 'ready', cwd: directory, sessionId: null });
}

async function handleResumeSession(ws, state, data) {
  const { sessionId, directory } = data;
  if (!sessionId) {
    send(ws, { type: 'error', message: '未指定会话 ID' });
    return;
  }

  // Interrupt any active query
  await interruptActive(state);

  state.cwd = directory || state.cwd;
  state.sessionId = sessionId;
  state.allowedTools.clear();
  state.permissionMode = data.permissionMode || state.permissionMode;

  // Load history
  try {
    const messages = await getSessionHistory(sessionId, state.cwd);
    send(ws, { type: 'history', sessionId, messages });
  } catch (err) {
    console.error('[ws] 加载历史失败:', err);
  }

  send(ws, { type: 'status', status: 'ready', cwd: state.cwd, sessionId });
}

// ── User input / query execution ──────────────────────────────────────

async function handleUserInput(ws, state, data) {
  const { content } = data;
  if (!content || !content.trim()) return;

  if (!state.cwd) {
    send(ws, { type: 'error', message: '请先选择一个工作目录' });
    return;
  }

  // Interrupt any active query before starting a new one
  await interruptActive(state);

  state.abortController = new AbortController();

  const canUseTool = createPermissionHandler(ws, state);

  // Echo user message back to frontend
  send(ws, { type: 'user_echo', content });

  try {
    const q = createQuery({
      prompt: content,
      cwd: state.cwd,
      resume: state.sessionId,
      permissionMode: state.permissionMode,
      abortController: state.abortController,
      canUseTool,
      model: state.currentModel,
    });

    state.activeQuery = q;

    send(ws, { type: 'status', status: 'thinking' });

    for await (const msg of q) {
      // Capture session info from init message
      if (msg.type === 'system' && msg.subtype === 'init' && msg.session_id) {
        state.sessionId = msg.session_id;
        send(ws, { type: 'session_info', sessionId: msg.session_id, cwd: msg.cwd, model: msg.model });

        // Get available skills for this session (excludes built-in commands)
        const initSkillNames = new Set(msg.skills || []);
        q.supportedCommands().then(commands => {
          const userSkills = getUserSkillNames();
          const skills = commands
            .filter(cmd => !userSkills.has(cmd.name))
            .map(cmd => ({
              name: cmd.name,
              description: cmd.description || '',
              argumentHint: cmd.argumentHint || ''
            }));
          send(ws, { type: 'skills_list', skills });
        }).catch(() => {
          send(ws, { type: 'skills_list', skills: [] });
        });

        // Send built-in slash command names (exclude all skills identified by init message)
        const slashCommands = (msg.slash_commands || []).filter(c => !initSkillNames.has(c));
        if (slashCommands.length > 0) {
          send(ws, { type: 'cmds_list', commands: slashCommands });
        }

        // Get MCP server status
        q.mcpServerStatus().then(servers => {
          send(ws, { type: 'mcp_list', servers });
        }).catch(() => {
          send(ws, { type: 'mcp_list', servers: [] });
        });

        // Get available models
        q.supportedModels().then(models => {
          state._lastModels = models;
          send(ws, { type: 'models_list', models, current: msg.model });
        }).catch(() => {});
      }

      forwardMessage(ws, msg);
    }

    state.activeQuery = null;
  } catch (err) {
    if (err.name === 'AbortError' || state.abortController?.signal.aborted) {
      send(ws, { type: 'status', status: 'cancelled' });
    } else if (err.message?.includes('[ede_diagnostic]')) {
      // SDK diagnostic — CLI ended a turn normally but flagged is_error=true.
      // The result message was already forwarded; treat this as normal completion.
      console.log('[ws] SDK diagnostic (normal):', err.message);
      send(ws, { type: 'status', status: 'done' });
    } else {
      console.error('[ws] query 错误:', err);
      send(ws, { type: 'error', message: err.message || '执行出错' });
      send(ws, { type: 'status', status: 'error' });
    }
    state.activeQuery = null;
  }
}

// ── Interrupt ──────────────────────────────────────────────────────────

function handleInterrupt(ws, state) {
  if (state.activeQuery) {
    try { state.activeQuery.interrupt(); } catch (err) {
      console.error('[ws] 中断失败:', err);
    }
    send(ws, { type: 'status', status: 'interrupting' });
  }
}

async function interruptActive(state) {
  if (state.activeQuery) {
    try { state.activeQuery.interrupt(); } catch {}
    try { state.abortController?.abort(); } catch {}
    // Small delay to let the async iterator finish
    await new Promise(r => setTimeout(r, 50));
  }
  state.activeQuery = null;
  state.abortController = null;

  // Clear pending permissions
  for (const [id, { resolve, timer }] of state.pendingPermissions) {
    clearTimeout(timer);
    resolve({ behavior: 'deny', message: '会话已切换' });
  }
  state.pendingPermissions.clear();
}

// ── Permission handling ────────────────────────────────────────────────

function createPermissionHandler(ws, state) {
  return async (toolName, input, options) => {
    // Auto-allow if user previously chose "don't ask again"
    if (state.allowedTools.has(toolName)) {
      return { behavior: 'allow', updatedInput: {} };
    }

    return new Promise((resolve) => {
      const toolUseID = options.toolUseID;

      // Set timeout: auto-deny after 5 minutes
      const timer = setTimeout(() => {
        state.pendingPermissions.delete(toolUseID);
        send(ws, { type: 'permission_timeout', toolUseID });
        resolve({ behavior: 'deny', message: '操作超时' });
      }, PERMISSION_TIMEOUT_MS);

      state.pendingPermissions.set(toolUseID, { resolve, timer });

      send(ws, {
        type: 'permission_request',
        toolUseID,
        toolName,
        input,
        title: options.title,
        displayName: options.displayName,
        description: options.description,
        decisionReason: options.decisionReason,
        blockedPath: options.blockedPath,
        suggestions: options.suggestions,
        agentID: options.agentID,
      });
    });
  };
}

function handlePermissionResponse(ws, state, data) {
  const { toolUseID, granted, persistent, toolName } = data;
  const pending = state.pendingPermissions.get(toolUseID);

  if (!pending) {
    // Might have timed out already
    return;
  }

  clearTimeout(pending.timer);
  state.pendingPermissions.delete(toolUseID);

  if (granted) {
    if (persistent && toolName) {
      state.allowedTools.add(toolName);
    }
    pending.resolve({ behavior: 'allow', updatedInput: {} });
  } else {
    pending.resolve({ behavior: 'deny', message: '用户拒绝' });
  }
}

// ── Directory picker ──────────────────────────────────────────────────

async function handlePickDirectory(ws, state) {
  const os = platform();

  if (os === 'win32') {
    // Use Shell.Application COM — works from Node.js MTA thread
    const ps = "$f=(New-Object -ComObject Shell.Application).BrowseForFolder(0,'Select working directory',0);if($f){$f.Self.Path}";
    exec(`powershell.exe -NoProfile -Command "${ps}"`, { timeout: 120000 }, (err, stdout) => {
      if (err || !stdout.trim()) {
        send(ws, { type: 'directory_pick_cancelled' });
        return;
      }
      const path = stdout.trim().replace(/[/\\]$/, '');
      if (path) {
        send(ws, { type: 'directory_picked', path });
      } else {
        send(ws, { type: 'directory_pick_cancelled' });
      }
    });
    return;
  }

  let command, args;
  if (os === 'darwin') {
    command = 'osascript';
    args = ['-e', 'POSIX path of (choose folder with prompt "选择项目工作目录")'];
  } else if (os === 'linux') {
    command = 'zenity';
    args = ['--file-selection', '--directory', '--title=选择项目工作目录'];
  } else {
    send(ws, { type: 'directory_pick_fallback' });
    return;
  }

  execFile(command, args, { timeout: 120000 }, (err, stdout) => {
    if (err) {
      send(ws, { type: 'directory_pick_cancelled' });
      return;
    }
    const path = stdout.trim().replace(/[/\\]$/, '');
    if (path) {
      send(ws, { type: 'directory_picked', path });
    } else {
      send(ws, { type: 'directory_pick_cancelled' });
    }
  });
}

// ── Rename session ─────────────────────────────────────────────────────

async function handleRenameSession(ws, state, data) {
  try {
    await renameSessionTitle(data.sessionId, data.title, state.cwd);
    send(ws, { type: 'session_renamed', sessionId: data.sessionId, title: data.title });
  } catch (err) {
    console.error('[ws] 重命名失败:', err);
    send(ws, { type: 'error', message: '重命名失败: ' + err.message });
  }
}

// ── Message forwarding ─────────────────────────────────────────────────

function forwardMessage(ws, msg) {
  switch (msg.type) {
    case 'assistant':
      // Full assistant message (complete content blocks)
      send(ws, {
        type: 'assistant',
        content: msg.message?.content || [],
        parent_tool_use_id: msg.parent_tool_use_id,
        uuid: msg.uuid,
        session_id: msg.session_id,
        error: msg.error,
      });
      break;

    case 'stream_event':
      // Partial streaming event
      send(ws, {
        type: 'stream_event',
        event: msg.event,
        parent_tool_use_id: msg.parent_tool_use_id,
        uuid: msg.uuid,
        session_id: msg.session_id,
        ttft_ms: msg.ttft_ms,
      });
      break;

    case 'tool_progress':
      send(ws, {
        type: 'tool_progress',
        tool_use_id: msg.tool_use_id,
        tool_name: msg.tool_name,
        elapsed_time_seconds: msg.elapsed_time_seconds,
        parent_tool_use_id: msg.parent_tool_use_id,
        task_id: msg.task_id,
        uuid: msg.uuid,
        session_id: msg.session_id,
      });
      break;

    case 'result':
      send(ws, {
        type: 'result',
        subtype: msg.subtype,
        duration_ms: msg.duration_ms,
        duration_api_ms: msg.duration_api_ms,
        num_turns: msg.num_turns,
        result: msg.result,
        stop_reason: msg.stop_reason,
        total_cost_usd: msg.total_cost_usd,
        usage: msg.usage,
        modelUsage: msg.modelUsage,
        permission_denials: msg.permission_denials,
        is_error: msg.is_error,
        uuid: msg.uuid,
        session_id: msg.session_id,
      });

      send(ws, { type: 'status', status: 'done' });
      break;

    case 'user': {
      // SDK replays user messages during resumed sessions.
      // Interrupt markers are synthetic, show as system messages.
      const userText = typeof msg.message === 'string'
        ? msg.message
        : (msg.message?.content?.[0]?.text || '');
      const isInterrupted = userText.includes('[Request interrupted by user');

      if (isInterrupted) {
        send(ws, { type: 'system', subtype: 'interrupted', message: '请求已被用户中断', uuid: msg.uuid, session_id: msg.session_id });
      } else {
        send(ws, { type: 'user', content: userText, uuid: msg.uuid, session_id: msg.session_id });
      }
      break;
    }

    case 'system':
      if (msg.subtype === 'init') {
        // Already handled above, skip
      } else if (msg.subtype === 'status') {
        send(ws, { type: 'status', status: msg.status, permissionMode: msg.permissionMode });
      } else if (msg.subtype === 'permission_denied') {
        send(ws, {
          type: 'permission_denied',
          tool_name: msg.tool_name,
          tool_use_id: msg.tool_use_id,
          message: msg.message,
          decision_reason: msg.decision_reason,
        });
      } else if (msg.subtype === 'compact_boundary') {
        send(ws, { type: 'system', subtype: 'compact_boundary', metadata: msg.compact_metadata });
      } else if (msg.subtype === 'local_command_output') {
        send(ws, { type: 'assistant', content: msg.content });
      }
      break;

    default:
      // For any other message types, send as generic
      send(ws, { type: 'unknown', raw: msg });
  }
}

// ── MCP management ────────────────────────────────────────────────────

async function handleMcpStatus(ws, state) {
  if (!state.activeQuery) {
    send(ws, { type: 'error', message: '没有活跃会话' });
    return;
  }
  try {
    const servers = await state.activeQuery.mcpServerStatus();
    send(ws, { type: 'mcp_list', servers });
  } catch (err) {
    send(ws, { type: 'error', message: '获取 MCP 状态失败: ' + err.message });
  }
}

async function handleMcpToggle(ws, state, data) {
  if (!state.activeQuery) {
    send(ws, { type: 'error', message: '没有活跃会话' });
    return;
  }
  const { serverName, enabled } = data;
  if (!serverName) {
    send(ws, { type: 'error', message: '未指定服务器名称' });
    return;
  }
  try {
    await state.activeQuery.toggleMcpServer(serverName, enabled);
    const servers = await state.activeQuery.mcpServerStatus();
    send(ws, { type: 'mcp_list', servers });
  } catch (err) {
    send(ws, { type: 'error', message: '切换 MCP 服务器失败: ' + err.message });
  }
}

async function handleMcpReconnect(ws, state, data) {
  if (!state.activeQuery) {
    send(ws, { type: 'error', message: '没有活跃会话' });
    return;
  }
  const { serverName } = data;
  if (!serverName) {
    send(ws, { type: 'error', message: '未指定服务器名称' });
    return;
  }
  try {
    await state.activeQuery.reconnectMcpServer(serverName);
    const servers = await state.activeQuery.mcpServerStatus();
    send(ws, { type: 'mcp_list', servers });
  } catch (err) {
    send(ws, { type: 'error', message: '重连 MCP 服务器失败: ' + err.message });
  }
}

async function handleModelSet(ws, state, data) {
  const { model } = data;
  if (!model) return;
  state.currentModel = model;
  if (state.activeQuery) {
    try {
      await state.activeQuery.setModel(model);
    } catch {}
  }
  send(ws, { type: 'models_list', models: state._lastModels || [], current: model });
}
