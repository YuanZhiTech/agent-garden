import { query, listSessions, getSessionMessages, renameSession } from '@anthropic-ai/claude-agent-sdk';

/**
 * Run a Claude query and yield SDKMessage objects.
 *
 * @param {Object} params
 * @param {string} params.prompt - User prompt text
 * @param {string} params.cwd - Working directory
 * @param {string} [params.resume] - Session ID to resume
 * @param {string} [params.permissionMode] - Permission mode
 * @param {AbortController} [params.abortController] - For interruption
 * @param {Function} [params.canUseTool] - Permission callback (toolName, input, options) => PermissionResult
 * @returns {AsyncGenerator<SDKMessage>}
 */
export function createQuery({ prompt, cwd, resume, permissionMode, abortController, canUseTool, model }) {
  const options = {
    cwd,
    permissionMode: permissionMode || 'default',
  };

  if (resume) options.resume = resume;
  if (abortController) options.abortController = abortController;
  if (canUseTool) options.canUseTool = canUseTool;
  if (model) options.model = model;

  return query({ prompt, options });
}

/**
 * List sessions, optionally filtered by directory.
 * @param {string} [dir]
 * @param {number} [limit]
 * @returns {Promise<SDKSessionInfo[]>}
 */
export async function listSessionsForDir(dir, limit) {
  const opts = {};
  if (dir) opts.dir = dir;
  if (limit) opts.limit = limit;
  return listSessions(opts);
}

/**
 * Get message history for a session.
 * @param {string} sessionId
 * @param {string} [dir]
 * @returns {Promise<SessionMessage[]>}
 */
export async function getSessionHistory(sessionId, dir) {
  const opts = {};
  if (dir) opts.dir = dir;
  return getSessionMessages(sessionId, opts);
}

/**
 * Rename a session.
 * @param {string} sessionId
 * @param {string} title
 * @param {string} [dir]
 */
export async function renameSessionTitle(sessionId, title, dir) {
  const opts = {};
  if (dir) opts.dir = dir;
  return renameSession(sessionId, title, opts);
}
