#!/usr/bin/env node
// 🌸 Agent花园版 Claude Code — Web UI 启动器（完全隔离版）

import { createServer } from 'node:net';
import { readFileSync, existsSync, mkdirSync } from 'node:fs';
import { exec } from 'node:child_process';
import { dirname, join } from 'node:path';
import { fileURLToPath } from 'node:url';
import { startServer } from './server/index.js';

const __dirname = dirname(fileURLToPath(import.meta.url));

// 完全隔离：把 HOME 设到空目录，避免扫到知识库
const ISOLATED_HOME = "/tmp/garden-home";
mkdirSync(ISOLATED_HOME + "/test-project", { recursive: true });
process.env.HOME = ISOLATED_HOME;
process.chdir(ISOLATED_HOME + "/test-project");

// DeepSeek 后端配置
process.env.ANTHROPIC_BASE_URL = "https://api.deepseek.com/anthropic";
process.env.ANTHROPIC_AUTH_TOKEN = "sk-11f12f2b7fa7441891fc80d9a909657a";
process.env.ANTHROPIC_MODEL = "deepseek-v4-flash[1m]";

// 禁止 Claude Code 访问用户目录
process.env.CLAUDE_CODE_ALLOWED_DIRS = ISOLATED_HOME;

// 读取本地配置，确定版本等级
const CONFIG_PATH = require("node:path").join(process.env.HOME || "/tmp", ".agent-garden", "config.json");
let configMode = "full";
if (existsSync(CONFIG_PATH)) {
  try {
    const cfg = JSON.parse(readFileSync(CONFIG_PATH, "utf-8"));
    if (cfg.tier === "basic") configMode = "basic";
  } catch(e) {}
}


function parseArgs() {
  const args = process.argv.slice(2);
  let port = null;
  let mode = configMode;
  for (let i = 0; i < args.length; i++) {
    if ((args[i] === '--port' || args[i] === '-p') && args[i + 1]) {
      port = parseInt(args[i + 1], 10);
      i++;
    }
    if (args[i] === '--mode' && args[i + 1]) {
      mode = args[i + 1];
      i++;
    }
  }
  return { port: port || 3458, mode };
}

function isPortAvailable(port) {
  return new Promise((resolve) => {
    const tester = createServer();
    tester.once('error', () => resolve(false));
    tester.once('listening', () => { tester.close(() => resolve(true)); });
    tester.listen(port);
  });
}

async function findAvailablePort(startPort) {
  for (let port = startPort; port <= 65535; port++) {
    if (await isPortAvailable(port)) return port;
  }
  console.error('无可用端口');
  process.exit(1);
}

function openBrowser(url) {
  const cmd = process.platform === 'darwin' ? `open "${url}"` :
              process.platform === 'win32' ? `start "" "${url}"` : `xdg-open "${url}"`;
  exec(cmd, () => {});
}

const { port: userPort, mode } = parseArgs();
const port = await findAvailablePort(userPort);

console.log('');
console.log('  🌸  Agent的花园 · Claude Code');
console.log('  ─────────────────────────────');
console.log(`  地址: http://localhost:${port}`);
console.log('  后端: DeepSeek V4 Flash');
console.log('');

// 设置 UI 模式（通过环境变量传递给 server）
process.env.GARDEN_MODE = mode;

startServer(port, (p) => {
  openBrowser(`http://localhost:${p}`);
});
