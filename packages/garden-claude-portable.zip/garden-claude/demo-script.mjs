import { chromium } from 'playwright';
import { mkdirSync, writeFileSync } from 'fs';

const PORT = 3459;  // Web UI port — change if different
const URL = `http://localhost:${PORT}`;

// Create demo folder on desktop
const DEMO_DIR = '/Users/zbbsjl_72/Desktop/demo';
mkdirSync(DEMO_DIR, { recursive: true });
writeFileSync(`${DEMO_DIR}/readme.md`, '# Demo\nThis is a demo folder for Agent Garden Code.');

const browser = await chromium.launch({
  headless: false,
  args: ['--start-maximized'],
});

const page = await browser.newPage({ viewport: null });

// ── 1. Open Web UI ──────────────────────────────────
console.log('Opening Web UI...');
await page.goto(URL, { waitUntil: 'networkidle' });
await page.waitForTimeout(3000);

// ── 2. Select working directory ──────────────────────
console.log('Selecting demo folder...');
// Click the directory picker button
const pickerBtn = page.locator('button:has-text("选择目录"), button:has-text("选择文件夹"), #btn-select-dir');
if (await pickerBtn.count() > 0) {
  await pickerBtn.click();
  await page.waitForTimeout(1000);
  // Type the path in the dialog
  const input = page.locator('input[type="text"], input[type="file"], .directory-input');
  if (await input.count() > 0) {
    await input.fill(DEMO_DIR);
    await page.keyboard.press('Enter');
  }
}
await page.waitForTimeout(2000);

console.log('=== DEMO READY ===');
console.log('The browser is visible. Recording can start.');
console.log('');
console.log('--- DEMO SCRIPT FOR NARRATION ---');
console.log('');
console.log('[00:00] 开场：这是 Agent花园·Code，一个普通人也能用的 AI 工作站');
console.log('[00:10] 界面展示：左边是会话列表，下面是输入框');
console.log('');
console.log('[00:20] 演示一：Skills 面板');
console.log('点击左上角 Skills 按钮 → 展示内置技能列表');
console.log('“这里有我们积累的各种实用技能，一键调用”');
console.log('');
console.log('[00:40] 演示二：MCP 面板');
console.log('点击 MCP 按钮 → 展示已连接的 MCP 服务');
console.log('“MCP 让 AI 能操作真实世界的工具”');
console.log('');
console.log('[01:00] 演示三：实际干活');
console.log('输入：“帮我写一个番茄钟网页，保存到这个文件夹”');
console.log('等待 Claude Code 生成代码 → 展示保存的文件');
console.log('“它不只是聊天，是真的能干活”');
console.log('');
console.log('[02:00] 结尾');
console.log('展示官网：agent-garden.com');
console.log('“199 元起，打开浏览器就能用的 AI 工作站”');
console.log('');
console.log('=== RECORDING GUIDE ===');
console.log('1. Start QuickTime recording (Shift+Cmd+5)');
console.log('2. Say "开始" when ready');
console.log('3. I will type the first prompt for you');
